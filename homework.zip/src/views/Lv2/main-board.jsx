const MainBoard = () => {
  return (
    <label>Main Board Page</label>
  )
};

export default MainBoard;