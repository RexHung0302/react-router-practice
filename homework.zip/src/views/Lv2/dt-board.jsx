const DTBoard = () => {
  return (
    <label>DT Board Page</label>
  )
};

export default DTBoard;