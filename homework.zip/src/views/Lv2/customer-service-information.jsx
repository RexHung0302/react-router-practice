const CustomerServiceInformation = () => {
  return (
    <label>Customer Service Information Page</label>
  )
};

export default CustomerServiceInformation;