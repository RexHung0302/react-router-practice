const Feedback = () => {
  return (
    <label>Feedback Page</label>
  )
};

export default Feedback;