const RichBoard = () => {
  return (
    <label>Rich Board Page</label>
  )
};

export default RichBoard;